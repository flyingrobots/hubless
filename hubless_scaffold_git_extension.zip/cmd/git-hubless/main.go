
package main

import (
	"fmt"
	"log"
	"os"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/flyingrobots/hubless/internal/ui/tui"
)

const helpText = `Hubless — GitHub without the website (git extension)

Usage:
  git hubless help
  git hubless create
  git hubless list [--assignee=me --status=open --label=bug]
  git hubless view <id>
  git hubless status <id> --to <state>
  git hubless assign <id> --to <user>
  git hubless comment <id>
  git hubless kanban [--board <name>]
  git hubless tui
  git hubless sync
  git hubless doctor
`

func main() {
	// Allow invocation as either `git-hubless` or `git hubless` (git finds git-hubless on PATH).
	args := os.Args[1:]
	if len(args) == 0 || args[0] == "help" || args[0] == "--help" || args[0] == "-h" {
		fmt.Print(helpText)
		return
	}
	switch args[0] {
	case "tui", "ui":
		m := tui.NewModel()
		if err := tea.NewProgram(m, tea.WithAltScreen()).Start(); err != nil {
			log.Fatal(err)
		}
	case "list":
		// TODO: wire to catalog query
		fmt.Println("#  Title                     Status       Assignee")
		fmt.Println("1  Wire stickers layout      open         james")
		fmt.Println("2  Git plumbing adapter      in-progress  james")
	case "create":
		fmt.Println("🍞 Creating a new issue (opens $EDITOR) — TODO")
	case "view":
		if len(args) < 2 {
			fmt.Println("usage: git hubless view <id>")
			os.Exit(1)
		}
		fmt.Printf("🔎 Issue %s — TODO: render details\n", args[1])
	case "kanban":
		fmt.Println("🧩 Kanban (TUI) — try `git hubless tui` for full layout")
	case "sync":
		fmt.Println("🔁 Syncing refs/hubless/** — TODO")
	case "status":
		fmt.Println("📌 Update status — TODO")
	case "assign":
		fmt.Println("👤 Assign — TODO")
	case "comment":
		fmt.Println("💬 Comment — TODO")
	case "doctor":
		fmt.Println("🩺 Doctor — checking repo state (TODO)")
	default:
		fmt.Printf("unknown subcommand: %s\n\n%s", strings.Join(args, " "), helpText)
		os.Exit(2)
	}
}
