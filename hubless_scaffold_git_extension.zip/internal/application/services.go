
package application

import "github.com/flyingrobots/hubless/internal/domain"

type Service struct{}

func (s *Service) CreateIssue(title string) (*domain.Issue, error) {
	return &domain.Issue{ID: "1", Title: title, Status: "open", Assignee: "james"}, nil
}
