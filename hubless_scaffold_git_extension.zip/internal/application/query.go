
package application

import "github.com/flyingrobots/hubless/internal/domain"

func (s *Service) ListIssues() ([]domain.Issue, error) {
	return []domain.Issue{
		{ID: "1", Title: "stickers layout", Status: "open", Assignee: "james"},
		{ID: "2", Title: "git plumbing", Status: "in-progress", Assignee: "james"},
	}, nil
}
