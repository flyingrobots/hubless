
package domain

type Event struct {
	Type    string
	IssueID string
	Actor   string
	TS      string
	Payload map[string]any
	Lamport int64
	EventID string
}
