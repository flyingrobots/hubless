
package domain

type Issue struct {
	ID       string
	Title    string
	Status   string
	Assignee string
}
