
package domain

type Board struct {
	Name   string
	Columns []string
}
