
package tui

import (
	"fmt"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/76creates/stickers"
)

type Model struct {
	layout *stickers.Flexbox
	width  int
	height int
}

func NewModel() Model {
	fb := stickers.NewFlexboxLayout()
	fb.SetRoot(
		stickers.Row().
			Add(stickers.Col(4).ID("list")).
			Add(stickers.Col(5).ID("board")).
			Add(stickers.Col(3).ID("detail")),
	)
	return Model{layout: fb}
}

func (m Model) Init() tea.Cmd { return nil }

func (m Model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
		m.layout.Resize(msg.Width, msg.Height)
	}
	return m, nil
}

func (m Model) View() string {
	// Placeholder content for each region
	list := "Issues:\n  #1 stickers layout (open)\n  #2 git plumbing (doing)"
	board := "[Open]    [Doing]    [Done]\n  #1        #2"
	detail := "Details:\n  Title: stickers layout\n  Assignee: james\n  Status: open"

	m.layout.GetNodeByID("list").SetContent(list)
	m.layout.GetNodeByID("board").SetContent(board)
	m.layout.GetNodeByID("detail").SetContent(detail)

	out := m.layout.Render()
	return out + fmt.Sprintf("\n(%dx%d)  ? help • q quit • j/k select • enter open", m.width, m.height)
}
