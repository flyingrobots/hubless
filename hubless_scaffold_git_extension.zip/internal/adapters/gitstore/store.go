
package gitstore

type Store struct {
	repo   string
	author string
	date   string
}

func NewStore(repo, author, date string) *Store {
	return &Store{repo: repo, author: author, date: date}
}

func (s *Store) RefHead(ref string) (string, error) {
	out, err := runGit(s.repo, "rev-parse", ref)
	if err != nil {
		return "", nil // not found is fine
	}
	return out, nil
}

func (s *Store) AppendEvent(issueID string, subject string, payload []byte) (string, error) {
	// Sketch: create empty tree and commit; update-ref. Real impl should create canonical messages.
	treeOID, _ := runGit(s.repo, "mktree")
	args := []string{"commit-tree", treeOID, "-m", subject, "-m", string(payload)}
	if head, _ := s.RefHead("refs/hubless/issues/" + issueID); head != "" {
		args = append(args, "-p", head)
	}
	oid, err := runGit(s.repo, args...)
	if err != nil {
		return "", err
	}
	_, err = runGit(s.repo, "update-ref", "refs/hubless/issues/"+issueID, strings.TrimSpace(oid))
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(oid), nil
}
