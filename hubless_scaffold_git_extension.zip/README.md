
# Hubless

**GitHub without the website.** Issues, PRs, boards, and discussions – all as Git-native data with a blazing TUI.

## Git Extension
This binary is installed as `git-hubless`, so you can type subcommands like:

```bash
git hubless help
git hubless create
git hubless list
git hubless tui
```

## Quickstart

```bash
git clone https://github.com/flyingrobots/hubless
cd hubless
make install
git hubless help
```

> Hubless persists planning data under `refs/hubless/**`. Everything is auditable, offline-first, and fast via a catalog index.
