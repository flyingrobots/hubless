
module github.com/flyingrobots/hubless

go 1.22

require (
    github.com/76creates/stickers v0.2.4 // indirect
    github.com/charmbracelet/bubbletea v0.25.0
    github.com/charmbracelet/bubbles v0.18.0
    github.com/charmbracelet/lipgloss v0.10.0
)
